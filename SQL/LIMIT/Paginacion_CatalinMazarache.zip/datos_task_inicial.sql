insert into `tasks`(`task_id`,`subject`,`start_date`,`end_date`,`description`) VALUES
(1,'DWES','2021-01-25','2021-01-29','Desarrollo Web en Entorno Servidor'),
(2,'DWEC','2021-01-25','2021-01-29','Desarrollo Web en Entorno Cliente'),
(3,'EIE','2021-01-25','2021-01-29','Empresa e iniciativa emprendedora'),
(4,'INTFZ','2021-01-25','2021-01-29','Interfaces'),
(5,'ING','2021-01-25','2021-01-29','Inglés'),
(6,'DESP','2021-01-25','2021-01-29','Despliegue');
