CREATE USER 'josemi@localhost' IDENTIFIED BY '1234';
GRANT SELECT ON dwes.usuarios TO josemi@localhost;