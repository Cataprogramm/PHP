<!DOCTYPE html>
<html lang="es">
<head>
	<title>Formulario</title>
	<meta charset="utf8">
	<meta name="author" content="Catalin Mazarache">
	<meta name="description" content="ataque XSS">
</head>

<body>

<form action="<?php echo $_SERVER['PHP_SELF'];?>" method="POST">
Nombre:<input type="text" name="nombre"><br>
<input type="submit" name="enviar"><br>
</form>


<?php
include_once('funciones.php');
	if(!empty($_POST['nombre'])){
		
		echo "Datos recibidos <br>";
		echo filtrado($_POST['nombre']);
		
	}
	else{
		echo "Escribe el nombre <br>";
	}


?>
</body>
</html>
