<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="author" content="Catalin">
	<meta name="description" content="Usuario">
	<title>Usuario</title>	
<style>
h1{
margin: auto;
text-align: center;
}
</style>	
	
</head>
<body>
<!---Crea un archivo HTML que contenga un formulario con campos para introducir el usuario y la pasword, y un
botón de envio. Establece el action del formulario al archivo MENSAJES.PHP y configura el método de envio como
GET. -->
	<form action="mensajes.php" method="get">
	<h1>Identificación de usuario</h1>
	
	<label for="nombre">Nombre:</label>
	<input type="text" name="nombre" minlength="5"><br><br>
	
	<label for="password">Password:</label>
	<input type="password" name="password" minlength="5"><br><br>
	
	<input type="submit" value="Entrar">
	</form>
	
	
<?php	
	$nombre=$_GET["nombre"];
	$password=$_GET["password"];
	$contrasenia=strrev($nombre);
	
	if(isset($_GET["nombre"]) && isset($_GET["password"])){
		if(strlen($nombre)>=5 && strcmp($contrasenia,$password)===0){
			echo $contrasenia . "<br>" ;
			echo "El usuario y la contrasenia coinciden, y su longitud es mayor de 5";
		}
	}
?>	
	

	
</body>
</html>