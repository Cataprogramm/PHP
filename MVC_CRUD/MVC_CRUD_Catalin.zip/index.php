<?php
//Añadir el archivo php de la carpeta controlador
require_once('controlador/controlador.php');


?>