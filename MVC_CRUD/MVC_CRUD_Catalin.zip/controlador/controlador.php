<?php
require_once('modelo/ConectaDB.php');

require_once('vista/vista.php');

?>