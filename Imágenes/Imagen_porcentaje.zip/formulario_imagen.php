<!DOCTYPE html>
<html lang="es">
<head>
	<title>Porcentaje</title>
	<meta charset="utf-8">
</head>
<body>
	<form action="PruebaImagen.php" method="GET">
		Porcentaje: <input type="number" name="porcentaje" min="0" max="100">
		<input type="submit">
	</form>
</body>
</html>