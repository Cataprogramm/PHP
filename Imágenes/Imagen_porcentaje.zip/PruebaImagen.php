<?php
$porcentaje = $_GET['porcentaje'];
   $porcentaje . '<br>';
if($porcentaje < 100) {
	$total = $porcentaje * 360 / 100;
	  $total . '<br>';
	$resto = 360 - $total;
	 $resto;
}else{
	die("El porcentaje debe ser menor de 100");
}
//Crea una nueva imagen
$imagen = imagecreate(500, 300);
//Asignar un color a la imagen
$fondo = imagecolorallocate($imagen, 100, 255, 255);
//Creamos los colores rojo,azul y negro a la imagen
$azul = imagecolorallocate($imagen, 0, 0, 255);
$rojo = imagecolorallocate($imagen, 255, 0, 0);
$negro = imagecolorallocate($imagen, 0, 0, 0);
//Dibujar un arco
imagearc($imagen, 250, 150, 200, 200, 0, 360, $negro);
//Dibuja un arco parcial y lo rellena
imagefilledarc($imagen, 250, 150, 180, 180, 0, $total, $azul, IMG_ARC_PIE);
imagefilledarc($imagen, 250, 150, 180, 180, $resto, 360, $rojo,IMG_ARC_PIE);

header("Content-Type:image/png");
imagepng($imagen);
imagedestroy($imagen);
?>